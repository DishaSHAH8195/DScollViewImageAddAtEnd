//
//  CollViewCell.swift
//  collViewImageAddAtEnd
//
//  Created by Disha on 6/5/18.
//  Copyright © 2018 Disha. All rights reserved.
//

import UIKit

class CollViewCell: UICollectionViewCell {
    
    @IBOutlet weak var btnSelectedImg: UIButton!
    @IBOutlet weak var btnRemove: UIButton!
    
    override func prepareForReuse() {
        super.prepareForReuse()
        btnSelectedImg.setBackgroundImage(UIImage(named:"plus-sign"), for: .normal)
    }
}
