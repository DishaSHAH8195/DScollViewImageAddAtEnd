//
//  ViewController.swift
//  collViewImageAddAtEnd
//
//  Created by Disha on 6/5/18.
//  Copyright © 2018 Disha. All rights reserved.
//

import UIKit

class ViewController: UIViewController ,ChoosePicture{
    
    @IBOutlet weak var collViewImages: UICollectionView!
    //
    var items = [UIImage]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @objc func buttonClicked(sender:UIButton)
    {
        takeAndChoosePhoto1()
    }
    @objc func buttonRmoveClicked(sender:UIButton)
    {
        var indexPath = IndexPath(row: sender.tag, section: 0)
        print(indexPath)
        
        collViewImages.performBatchUpdates({
            self.items.remove(at: indexPath.row)
            collViewImages.deleteItems(at: [indexPath])
        }) { (finished) in
            self.collViewImages.reloadItems(at:[indexPath])
        }
    }
}

extension ViewController : UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return items.count + 1
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath) as! CollViewCell
        if indexPath.row == items.count{
            cell.btnSelectedImg.addTarget(self,action:#selector(buttonClicked),for:.touchUpInside)
            cell.btnRemove.isHidden = true
        }
        else{
            if items.indices.contains(indexPath.row) {
                cell.btnSelectedImg.setBackgroundImage(items[indexPath.row], for: .normal)
                cell.btnRemove.isHidden = false
                cell.btnRemove.tag = indexPath.row
                cell.btnRemove.addTarget(self,action:#selector(buttonRmoveClicked),for:.touchUpInside)
            }
        }
        return cell
    }
}

extension ViewController : UIImagePickerControllerDelegate,UINavigationControllerDelegate{
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        let choosenImage = info[UIImagePickerControllerEditedImage] as! UIImage
        //Change 1
        self.items.append(choosenImage)
        //Change 2
        collViewImages.reloadData()
        dismiss(animated: true, completion: nil)
    }
}

